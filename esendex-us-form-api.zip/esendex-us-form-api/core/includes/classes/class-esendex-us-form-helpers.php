<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Class Esendex_Us_Form_Helpers
 *
 * This class contains repetitive functions that
 * are used globally within the plugin.
 *
 * @package		ESENDEXUSF
 * @subpackage	Classes/Esendex_Us_Form_Helpers
 * @author		500designs
 * @since		1.0.0
 */
class Esendex_Us_Form_Helpers{

	/**
	 * ######################
	 * ###
	 * #### CALLABLE FUNCTIONS
	 * ###
	 * ######################
	 */

}
